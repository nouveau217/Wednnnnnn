(() => {
  const API = (window.BYEPASS_API_BASE || '').replace(/\/$/, '');
  window.BYEPASS_API = API;
  const $ = (id) => document.getElementById(id);
  document.querySelectorAll('[data-menu]').forEach((btn) => btn.addEventListener('click', () => $('navlinks')?.classList.toggle('open')));
  document.querySelectorAll('[data-copy-target]').forEach((btn) => btn.addEventListener('click', async () => {
    const target = $(btn.dataset.copyTarget);
    if (!target) return;
    try { await navigator.clipboard.writeText(target.innerText); btn.textContent = 'Copied'; setTimeout(() => btn.textContent = 'Copy', 1200); }
    catch { btn.textContent = 'Select text'; }
  }));
  const health = $('api-health');
  if (health) {
    if (!API || API.includes('YOUR-VPS-DOMAIN')) health.textContent = 'Set your VPS URL in config.js';
    else fetch(`${API}/health`, {headers:{'Accept':'application/json'}}).then(r => r.ok ? r.json() : Promise.reject()).then(() => {health.textContent='API online';health.classList.add('online')}).catch(()=>{health.textContent='API unreachable';health.classList.add('offline')});
  }
  const testForm = $('key-test-form');
  if (testForm) testForm.addEventListener('submit', async (e) => {
    e.preventDefault(); const result = $('key-test-result'); const key = $('test-api-key').value.trim();
    if (!API || API.includes('YOUR-VPS-DOMAIN')) {result.className='notice bad';result.textContent='Configure BYEPASS_API_BASE in config.js first.';return;}
    result.className='notice';result.textContent='Checking key…';
    try { const r=await fetch(`${API}/v1/me`,{headers:{Authorization:`Bearer ${key}`,'Accept':'application/json'}}); const d=await r.json(); result.className=`notice ${r.ok?'good':'bad'}`;result.textContent=r.ok?`Valid key · ${d.credits_remaining} credits remaining · prefix ${d.key_prefix}`:(d.error||'Request failed'); }
    catch {result.className='notice bad';result.textContent='Could not reach the API. Check the VPS URL and CORS settings.';}
  });
})();
