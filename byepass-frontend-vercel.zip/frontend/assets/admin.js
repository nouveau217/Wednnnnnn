(() => {
  const $ = (id) => document.getElementById(id);
  const API = (window.BYEPASS_API_BASE || '').replace(/\/$/, '');
  let token = '';
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function message(id, text, kind='') { const el=$(id); if(!el)return; el.textContent=text; el.className=`notice ${kind}`.trim(); }
  async function call(path, opts={}) {
    if (!API || API.includes('YOUR-VPS-DOMAIN')) throw new Error('ตั้งค่า VPS URL ใน config.js ก่อน');
    const headers = {'Accept':'application/json', ...(opts.headers||{})};
    if (token) headers['x-admin-token'] = token;
    if (opts.body) headers['Content-Type'] = 'application/json';
    const res = await fetch(`${API}${path}`, {...opts, headers});
    const data = await res.json().catch(()=>({error:'Invalid API response'}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }
  $('admin-login-form')?.addEventListener('submit', async (e)=>{
    e.preventDefault(); token=$('admin-token').value.trim();
    try { const d=await call('/admin/keys'); $('admin-dashboard').classList.remove('hidden'); message('admin-message',`เชื่อมต่อสำเร็จ · พบ ${d.keys.length} keys`,'good'); renderKeys(d.keys); }
    catch(err) { token=''; $('admin-dashboard').classList.add('hidden'); message('admin-message',err.message,'bad'); }
  });
  function renderKeys(keys) {
    const body=$('keys-table');
    if(!keys.length){body.innerHTML='<tr><td colspan="6" class="muted">ยังไม่มี API key</td></tr>';return;}
    body.innerHTML=keys.map(k=>`<tr><td><b>${esc(k.label)}</b><br><span class="mono muted">${esc(k.key_prefix)}</span></td><td><span class="mono">${esc(k.id)}</span><br><button class="btn small subtle" data-copy-id="${esc(k.id)}" type="button">คัดลอก ID</button></td><td>${Number(k.credits_remaining).toLocaleString()}</td><td><span class="status ${k.active?'active':'disabled'}">${k.active?'ACTIVE':'DISABLED'}</span></td><td>${esc(k.last_used_at || 'Never')}</td><td>${k.active?`<button class="btn small subtle" data-disable="${esc(k.id)}" type="button">ปิดคีย์</button>`:'—'}</td></tr>`).join('');
    body.querySelectorAll('[data-disable]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('ต้องการปิดใช้งาน API key นี้หรือไม่?'))return;try{await call(`/admin/keys/${encodeURIComponent(b.dataset.disable)}/disable`,{method:'POST'});message('keys-message','ปิดใช้งานคีย์แล้ว','good');await refresh();}catch(e){message('keys-message',e.message,'bad')}}));
    body.querySelectorAll('[data-copy-id]').forEach(b=>b.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(b.dataset.copyId);b.textContent='คัดลอกแล้ว'}catch{b.textContent='คัดลอกไม่ได้'}}));
  }
  async function refresh(){try{const d=await call('/admin/keys');renderKeys(d.keys);message('keys-message',`โหลดสำเร็จ · ${d.keys.length} keys`,'good')}catch(e){message('keys-message',e.message,'bad')}}
  $('refresh-keys')?.addEventListener('click',refresh);
  $('create-key-form')?.addEventListener('submit',async(e)=>{e.preventDefault();const label=$('key-label').value.trim();const credits=Number($('key-credits').value);try{const d=await call('/admin/keys',{method:'POST',body:JSON.stringify({label,credits})});$('new-key-value').textContent=d.api_key;$('new-key-wrap').classList.remove('hidden');message('admin-message','สร้าง API key แล้ว — โปรดคัดลอกเก็บไว้ก่อนซ่อน','good');$('key-label').value='';await refresh()}catch(err){message('admin-message',err.message,'bad')}});
  $('copy-new-key')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('new-key-value').textContent);$('copy-new-key').textContent='คัดลอกแล้ว'}catch{message('admin-message','คัดลอกอัตโนมัติไม่ได้ กรุณาเลือกข้อความคัดลอกเอง','bad')}});
  $('hide-new-key')?.addEventListener('click',()=>{$('new-key-value').textContent='';$('new-key-wrap').classList.add('hidden')});
  $('add-credits-form')?.addEventListener('submit',async(e)=>{e.preventDefault();const id=$('credits-key-id').value.trim();const credits=Number($('credits-amount').value);try{const d=await call(`/admin/keys/${encodeURIComponent(id)}/credits`,{method:'POST',body:JSON.stringify({credits})});message('credits-message',`เติมเครดิตสำเร็จ · คงเหลือ ${d.credits_remaining}`,'good');await refresh()}catch(err){message('credits-message',err.message,'bad')}});
})();
