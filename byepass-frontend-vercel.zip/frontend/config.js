/* Set this to your public VPS API URL before deploying the frontend. No trailing slash. */
window.BYEPASS_API_BASE = "https://YOUR-VPS-DOMAIN.example";
